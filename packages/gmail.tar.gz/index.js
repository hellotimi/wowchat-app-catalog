module.exports = Ferdium => Ferdium;
